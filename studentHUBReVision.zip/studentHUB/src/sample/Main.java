// Author: Jacob Lavoie 1108243
// STUDENT HUB TEMPLATE
package sample;
// import various java libraries for proper execution
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.layout.VBox;

// public class main extends application subclass
public class Main extends Application {

    // load image
    Image logo = new Image("file:logo.png");
    // override basic functionality
    @Override
    // public void function start contains stage object which throws exception for display error
    public void start(Stage primaryStage) throws Exception{

        // title for window
        primaryStage.setTitle("myResidence: STUDENT");
        // window width
        primaryStage.setWidth(600);
        // window height
        primaryStage.setHeight(500);

        // initialize VBoxes for displaying attributes
        VBox stageStuSet = new VBox(); // full stage set
        VBox studentPermissions = new VBox(); // student permission list set

        Label welcomeStu = new Label("Welcome" + "     [PLACEHOLDER]"); // Add first name of manager from database
        welcomeStu.setFont(new Font("Helvetica", 12));
        Label selectServ = new Label("Select a Feature:");
        selectServ.setFont(new Font("Helvetica", 24));

        // set on action brings them to search screen
        Button searchRoom = new Button("Search for a Room");
        // set on action brings them to register screen
        Button registerRoom = new Button("Register for a Room");

        ImageView showLogo = new ImageView();
        showLogo.setImage(logo);

        studentPermissions.getChildren().addAll(selectServ, searchRoom, registerRoom);
        studentPermissions.setAlignment(Pos.CENTER);
        studentPermissions.setSpacing(15);

        stageStuSet.getChildren().addAll(showLogo, welcomeStu, studentPermissions);
        stageStuSet.setAlignment(Pos.CENTER);
        stageStuSet.setSpacing(5);

        FlowPane studentHub = new FlowPane();
        studentHub.getChildren().addAll(stageStuSet);
        studentHub.setAlignment(Pos.CENTER);

        Scene stuHubScreen = new Scene(studentHub, 300, 250);
        primaryStage.setScene(stuHubScreen);
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
