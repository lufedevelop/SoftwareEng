package sample;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        // title for window
        primaryStage.setTitle("View all Pending Modifications");
        // window width
        primaryStage.setWidth(600);
        // window height
        primaryStage.setHeight(500);

        VBox pendModHub = new VBox();
        HBox cyclePends = new HBox();
        HBox decideMod = new HBox();

        Label pendModTitle = new Label("Pending Modifications:");
        // set on action
            // if no pends exist currently
                // return pend Label "No new Pends!" -- green Text
            // else
                // return pend Label room number requested for mod from database
        Button newPends = new Button("VIEW PENDING MODIFICATIONS");
        Label pend = new Label("[PLACEHOLDER ROOM]");
        List<Label> pendList = new List<Label>() {
            @Override
            public int size() {
                // size equals to number of pending mods
                return 0;
            }

            @Override
            public boolean isEmpty() {
                // if size returns >= 1
                return false;
                // if size returns 0
                    // return true
            }

            @Override
            public boolean contains(Object o) {
                return false;
            }

            @Override
            public Iterator<Label> iterator() {
                return null;
            }

            @Override
            public Object[] toArray() {
                // list will map entries to array
                return new Object[0];
            }

            @Override
            public <T> T[] toArray(T[] a) {
                return null;
            }

            @Override
            public boolean add(Label label) {
                return false;
            }

            @Override
            public boolean remove(Object o) {
                return false;
            }

            @Override
            public boolean containsAll(Collection<?> c) {
                return false;
            }

            @Override
            public boolean addAll(Collection<? extends Label> c) {
                return false;
            }

            @Override
            public boolean addAll(int index, Collection<? extends Label> c) {
                return false;
            }

            @Override
            public boolean removeAll(Collection<?> c) {
                return false;
            }

            @Override
            public boolean retainAll(Collection<?> c) {
                return false;
            }

            @Override
            public void clear() {

            }

            @Override
            public Label get(int index) {
                return null;
            }

            @Override
            public Label set(int index, Label element) {
                return null;
            }

            @Override
            public void add(int index, Label element) {

            }

            @Override
            public Label remove(int index) {
                return null;
            }

            @Override
            public int indexOf(Object o) {
                return 0;
            }

            @Override
            public int lastIndexOf(Object o) {
                return 0;
            }

            @Override
            public ListIterator<Label> listIterator() {
                return null;
            }

            @Override
            public ListIterator<Label> listIterator(int index) {
                return null;
            }

            @Override
            public List<Label> subList(int fromIndex, int toIndex) {
                return null;
            }
        };

        Button approveMod = new Button("APPROVE MOD");
        Button denyMod = new Button("DENY MOD");
        decideMod.getChildren().addAll(approveMod, denyMod);
        decideMod.setSpacing(10);

        Button nextMod = new Button("NEXT MOD");
        Button backMod = new Button("PREVIOUS MOD");
        cyclePends.getChildren().addAll(nextMod, backMod);
        cyclePends.setSpacing(10);

        Button backToMod = new Button("RETURN TO MODIFICATIONS");
        Button goBack = new Button("BACK TO HUB");

        pendModHub.getChildren().addAll(pendModTitle, newPends, pend, decideMod, cyclePends, backToMod, goBack);
        pendModHub.setSpacing(15);

        FlowPane pendFlow = new FlowPane();
        pendFlow.getChildren().addAll(pendModHub);
        pendFlow.setAlignment(Pos.CENTER);

        Scene pendScreen = new Scene(pendFlow);
        primaryStage.setScene(pendScreen);
        primaryStage.show();


    }


    public static void main(String[] args) {
        launch(args);
    }
}
