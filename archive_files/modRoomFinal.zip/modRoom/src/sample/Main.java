package sample;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        // title for window
        primaryStage.setTitle("Modify a Room");
        // window width
        primaryStage.setWidth(600);
        // window height
        primaryStage.setHeight(500);

        VBox modifyPermissions = new VBox();
        HBox modButtons = new HBox();

        Label modServ = new Label("Enter a Room ID");

        TextField roomModInput = new TextField();

        Label displayModInfo = new Label("");
        // set on action
            // if room is occupied
                // displayModInfo = "Room cannot be modified! Empty first!"
            // if room already has request
                // displayModInfo = "Room already under modification!"
            // else
                // displayModInfo = "Modification Request Ticket Sent"
        Button requestMod = new Button("Request Mod");

        // set on action
            // if request not been approved
                // displayModInfo = "Request for Mod not Approved Yet!"
            // else
                // displayModInfo = "Modification Performed"
        Button performMod = new Button("Perform Mod");

        // set on action
            // if mod has been requested, but not performed or not finished
                // displayModInfo = "Modification must be complete before Room can return to registration"
            // else
                // displayModInfo = "Modification closed Successfully"
        Button closeMod = new Button("Close Mod");
        Button pendingMods = new Button("VIEW PENDING MODIFICATIONS");

        modButtons.getChildren().addAll(requestMod, performMod, closeMod);
        modButtons.setSpacing(5);

        modifyPermissions.getChildren().addAll(modServ, roomModInput, modButtons, pendingMods);
        modifyPermissions.setSpacing(15);

        FlowPane modHub = new FlowPane();
        modHub.getChildren().addAll(modifyPermissions);
        modHub.setAlignment(Pos.CENTER);

        Scene modHubScreen = new Scene(modHub, 300, 250);
        primaryStage.setScene(modHubScreen);
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
