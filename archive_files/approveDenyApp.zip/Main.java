package sample;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception{
        // title for window
        primaryStage.setTitle("Approve / Deny Student Application");
        // window width
        primaryStage.setWidth(600);
        // window height
        primaryStage.setHeight(500);

        VBox appDenPermissions = new VBox();
        HBox buttonAppDen = new HBox();

        Label appDenServ = new Label("Approve or Deny Student Applications");
        Label appDenCheck = new Label("");
            // if number of outstanding apps >= 1
                // appDenCheck = "Outstanding Applications Exist!" -- red
            //else
                // appDenCheck = "No outstanding Applications" -- green
        Label errorCheckingApp = new Label("");
        Label stuName = new Label("");
        Label stuID = new Label("");
        Label stuRequest = new Label("");
        // set action
            // if no new applications exist
                // errorCheckingApp = "No applications to view!"
            // else
                // stuName = f_name database variable
                // stuID = stu_ID database variable
                // stuRequest = application
        Button viewApp = new Button("View Next Application");

        // set on action
            // if no application is present to approve / deny
                // errorCheckingApp = "No application present!"
            // else
                // continue
        Button approveStu = new Button("APPROVE");
        Button denyStu = new Button("DENY");

        buttonAppDen.getChildren().addAll(approveStu, denyStu);
        appDenPermissions.getChildren().addAll(appDenServ, appDenCheck, viewApp, errorCheckingApp, stuName, stuID, stuRequest, buttonAppDen);
        appDenPermissions.setSpacing(15);

        FlowPane appDenHub = new FlowPane();
        appDenHub.getChildren().addAll(appDenPermissions);
        appDenHub.setAlignment(Pos.CENTER);

        Scene appDenHubScreen = new Scene(appDenHub);
        primaryStage.setScene(appDenHubScreen);
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
